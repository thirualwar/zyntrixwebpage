(function(g) {
    var window = this;
    'use strict';
    var YtY = function(q) {
            q.mutedAutoplay = !1;
            q.endSeconds = NaN;
            q.limitedPlaybackDurationInSeconds = NaN;
            g.PS(q)
        },
        ow1 = function() {
            return {
                D: "svg",
                N: {
                    height: "100%",
                    version: "1.1",
                    viewBox: "0 0 110 26",
                    width: "100%"
                },
                G: [{
                    D: "path",
                    z8: !0,
                    B: "ytp-svg-fill",
                    N: {
                        d: "M 16.68,.99 C 13.55,1.03 7.02,1.16 4.99,1.68 c -1.49,.4 -2.59,1.6 -2.99,3 -0.69,2.7 -0.68,8.31 -0.68,8.31 0,0 -0.01,5.61 .68,8.31 .39,1.5 1.59,2.6 2.99,3 2.69,.7 13.40,.68 13.40,.68 0,0 10.70,.01 13.40,-0.68 1.5,-0.4 2.59,-1.6 2.99,-3 .69,-2.7 .68,-8.31 .68,-8.31 0,0 .11,-5.61 -0.68,-8.31 -0.4,-1.5 -1.59,-2.6 -2.99,-3 C 29.11,.98 18.40,.99 18.40,.99 c 0,0 -0.67,-0.01 -1.71,0 z m 72.21,.90 0,21.28 2.78,0 .31,-1.37 .09,0 c .3,.5 .71,.88 1.21,1.18 .5,.3 1.08,.40 1.68,.40 1.1,0 1.99,-0.49 2.49,-1.59 .5,-1.1 .81,-2.70 .81,-4.90 l 0,-2.40 c 0,-1.6 -0.11,-2.90 -0.31,-3.90 -0.2,-0.89 -0.5,-1.59 -1,-2.09 -0.5,-0.4 -1.10,-0.59 -1.90,-0.59 -0.59,0 -1.18,.19 -1.68,.49 -0.49,.3 -1.01,.80 -1.21,1.40 l 0,-7.90 -3.28,0 z m -49.99,.78 3.90,13.90 .18,6.71 3.31,0 0,-6.71 3.87,-13.90 -3.37,0 -1.40,6.31 c -0.4,1.89 -0.71,3.19 -0.81,3.99 l -0.09,0 c -0.2,-1.1 -0.51,-2.4 -0.81,-3.99 l -1.37,-6.31 -3.40,0 z m 29.59,0 0,2.71 3.40,0 0,17.90 3.28,0 0,-17.90 3.40,0 c 0,0 .00,-2.71 -0.09,-2.71 l -9.99,0 z m -53.49,5.12 8.90,5.18 -8.90,5.09 0,-10.28 z m 89.40,.09 c -1.7,0 -2.89,.59 -3.59,1.59 -0.69,.99 -0.99,2.60 -0.99,4.90 l 0,2.59 c 0,2.2 .30,3.90 .99,4.90 .7,1.1 1.8,1.59 3.5,1.59 1.4,0 2.38,-0.3 3.18,-1 .7,-0.7 1.09,-1.69 1.09,-3.09 l 0,-0.5 -2.90,-0.21 c 0,1 -0.08,1.6 -0.28,2 -0.1,.4 -0.5,.62 -1,.62 -0.3,0 -0.61,-0.11 -0.81,-0.31 -0.2,-0.3 -0.30,-0.59 -0.40,-1.09 -0.1,-0.5 -0.09,-1.21 -0.09,-2.21 l 0,-0.78 5.71,-0.09 0,-2.62 c 0,-1.6 -0.10,-2.78 -0.40,-3.68 -0.2,-0.89 -0.71,-1.59 -1.31,-1.99 -0.7,-0.4 -1.48,-0.59 -2.68,-0.59 z m -50.49,.09 c -1.09,0 -2.01,.18 -2.71,.68 -0.7,.4 -1.2,1.12 -1.49,2.12 -0.3,1 -0.5,2.27 -0.5,3.87 l 0,2.21 c 0,1.5 .10,2.78 .40,3.78 .2,.9 .70,1.62 1.40,2.12 .69,.5 1.71,.68 2.81,.78 1.19,0 2.08,-0.28 2.78,-0.68 .69,-0.4 1.09,-1.09 1.49,-2.09 .39,-1 .49,-2.30 .49,-3.90 l 0,-2.21 c 0,-1.6 -0.2,-2.87 -0.49,-3.87 -0.3,-0.89 -0.8,-1.62 -1.49,-2.12 -0.7,-0.5 -1.58,-0.68 -2.68,-0.68 z m 12.18,.09 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.18,-0.70 -0.18,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .18,2.39 .68,3.09 .49,.7 1.21,1 2.21,1 1.4,0 2.48,-0.69 3.18,-2.09 l .09,0 .31,1.78 2.59,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 17.31,0 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.21,-0.70 -0.21,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .21,2.39 .71,3.09 .5,.7 1.18,1 2.18,1 1.39,0 2.51,-0.69 3.21,-2.09 l .09,0 .28,1.78 2.62,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 20.90,2.09 c .4,0 .58,.11 .78,.31 .2,.3 .30,.59 .40,1.09 .1,.5 .09,1.21 .09,2.21 l 0,1.09 -2.5,0 0,-1.09 c 0,-1 -0.00,-1.71 .09,-2.21 0,-0.4 .11,-0.8 .31,-1 .2,-0.3 .51,-0.40 .81,-0.40 z m -50.49,.12 c .5,0 .8,.18 1,.68 .19,.5 .28,1.30 .28,2.40 l 0,4.68 c 0,1.1 -0.08,1.90 -0.28,2.40 -0.2,.5 -0.5,.68 -1,.68 -0.5,0 -0.79,-0.18 -0.99,-0.68 -0.2,-0.5 -0.31,-1.30 -0.31,-2.40 l 0,-4.68 c 0,-1.1 .11,-1.90 .31,-2.40 .2,-0.5 .49,-0.68 .99,-0.68 z m 39.68,.09 c .3,0 .61,.10 .81,.40 .2,.3 .27,.67 .37,1.37 .1,.6 .12,1.51 .12,2.71 l .09,1.90 c 0,1.1 .00,1.99 -0.09,2.59 -0.1,.6 -0.19,1.08 -0.49,1.28 -0.2,.3 -0.50,.40 -0.90,.40 -0.3,0 -0.51,-0.08 -0.81,-0.18 -0.2,-0.1 -0.39,-0.29 -0.59,-0.59 l 0,-8.5 c .1,-0.4 .29,-0.7 .59,-1 .3,-0.3 .60,-0.40 .90,-0.40 z"
                    }
                }]
            }
        },
        IwN = function() {
            return {
                D: "svg",
                N: {
                    fill: "none",
                    height: "100%",
                    viewBox: "0 0 143 51",
                    width: "100%"
                },
                G: [{
                    D: "path",
                    N: {
                        d: "M58.37 41.39H62.79V27.23C62.79 23.03 62.69 18.69 62.43 13.59H62.93L63.69 16.89L68.67 41.39H73.17L78.07 16.89L78.89 13.59H79.37C79.15 18.45 79.03 22.89 79.03 27.23V41.39H83.45V8.79H75.95L73.41 20.81C72.35 25.85 71.51 32.01 71.01 35.19H70.73C70.33 31.95 69.49 25.81 68.41 20.85L65.81 8.79H58.37V41.39Z",
                        fill: "white"
                    }
                }, {
                    D: "path",
                    N: {
                        d: "M91.45 41.73C93.91 41.73 95.83 40.59 97.17 38.13H97.35L97.69 41.39H101.43V17.73H96.47V36.61C95.91 37.67 94.81 38.29 93.73 38.29C92.33 38.29 91.89 37.17 91.89 35.13V17.73H86.93V35.43C86.93 39.49 88.19 41.73 91.45 41.73Z",
                        fill: "white"
                    }
                }, {
                    D: "path",
                    N: {
                        d: "M110.79 41.89C115.15 41.89 117.75 39.83 117.75 35.65C117.75 31.79 115.93 30.39 111.85 27.47C109.67 25.91 108.39 25.09 108.39 22.95C108.39 21.47 109.27 20.61 110.89 20.61C112.69 20.61 113.33 21.81 113.33 25.29L117.45 25.07C117.77 19.57 115.71 17.23 110.97 17.23C106.57 17.23 104.17 19.27 104.17 23.45C104.17 27.25 105.97 28.83 108.93 31.03C111.89 33.23 113.55 34.53 113.55 36.23C113.55 37.75 112.51 38.61 111.01 38.61C109.13 38.61 108.11 36.97 108.29 34.41L104.21 34.49C103.51 39.25 105.89 41.89 110.79 41.89Z",
                        fill: "white"
                    }
                }, {
                    D: "path",
                    N: {
                        d: "M122.5 14.59C124.22 14.59 125.04 13.99 125.04 11.59C125.04 9.33 124.16 8.65 122.5 8.65C120.84 8.65 119.94 9.27 119.94 11.59C119.94 13.99 120.82 14.59 122.5 14.59ZM120.2 41.39H125V17.73H120.2V41.39Z",
                        fill: "white"
                    }
                }, {
                    D: "path",
                    N: {
                        d: "M134.95 41.79C137.31 41.79 138.63 41.49 139.71 40.47C141.31 39.01 141.97 36.63 141.85 33.11L137.41 32.87C137.41 36.87 136.81 38.45 135.03 38.45C133.13 38.45 132.77 36.45 132.77 31.97V27.21C132.77 22.41 133.23 20.51 135.07 20.51C136.67 20.51 137.29 22.01 137.29 26.47L141.65 26.15C141.97 22.93 141.59 20.29 140.09 18.83C139.01 17.77 137.37 17.29 135.15 17.29C129.65 17.29 127.75 20.73 127.75 28.03V31.17C127.75 38.47 129.23 41.79 134.95 41.79Z",
                        fill: "white"
                    }
                }, {
                    D: "path",
                    N: {
                        "clip-rule": "evenodd",
                        d: "M24.99 49C29.74 49.00 34.38 47.59 38.32 44.95C42.27 42.32 45.35 38.57 47.17 34.18C48.98 29.80 49.46 24.97 48.53 20.32C47.61 15.66 45.32 11.38 41.97 8.03C38.61 4.67 34.33 2.38 29.68 1.46C25.02 .53 20.20 1.01 15.81 2.82C11.43 4.64 7.68 7.71 5.04 11.66C2.40 15.61 1 20.25 1 25C0.99 28.15 1.61 31.27 2.82 34.18C4.03 37.09 5.79 39.74 8.02 41.97C10.25 44.19 12.89 45.96 15.81 47.17C18.72 48.37 21.84 49 24.99 49ZM24.99 12.36C27.49 12.36 29.94 13.10 32.02 14.48C34.10 15.87 35.72 17.84 36.68 20.15C37.64 22.46 37.89 25.01 37.41 27.46C36.92 29.91 35.72 32.17 33.95 33.94C32.18 35.70 29.93 36.91 27.48 37.40C25.02 37.89 22.48 37.64 20.17 36.68C17.86 35.72 15.88 34.10 14.50 32.02C13.11 29.94 12.37 27.50 12.37 25C12.37 21.65 13.70 18.44 16.07 16.07C18.43 13.70 21.64 12.37 24.99 12.36ZM24.99 10.43C22.11 10.43 19.29 11.28 16.89 12.88C14.50 14.48 12.63 16.76 11.53 19.42C10.42 22.09 10.13 25.02 10.70 27.85C11.26 30.67 12.65 33.27 14.69 35.31C16.73 37.35 19.32 38.73 22.15 39.30C24.98 39.86 27.91 39.57 30.57 38.46C33.23 37.36 35.51 35.49 37.11 33.09C38.71 30.70 39.57 27.88 39.56 25C39.56 23.08 39.19 21.19 38.46 19.42C37.72 17.65 36.65 16.04 35.30 14.69C33.94 13.34 32.34 12.27 30.57 11.53C28.80 10.80 26.90 10.43 24.99 10.43ZM32.63 24.99L20.36 32.09V17.91L32.63 24.99Z",
                        fill: "white",
                        "fill-rule": "evenodd"
                    }
                }]
            }
        },
        HRY = function(q) {
            g.N.call(this, {
                D: "div",
                B: "ytp-related-on-error-overlay"
            });
            var J = this;
            this.api = q;
            this.K = this.C = 0;
            this.W = new g.uy(this);
            this.V = [];
            this.suggestionData = [];
            this.columns = this.containerWidth = 0;
            this.title = new g.N({
                D: "h2",
                B: "ytp-related-title",
                mI: "{{title}}"
            });
            this.previous = new g.N({
                D: "button",
                O1: ["ytp-button", "ytp-previous"],
                N: {
                    "aria-label": "Show previous suggested videos"
                },
                G: [g.Z6()]
            });
            this.X = new g.b0(function(E) {
                J.suggestions.element.scrollLeft = -E
            });
            this.L = this.scrollPosition = 0;
            this.S = !0;
            this.next = new g.N({
                D: "button",
                O1: ["ytp-button", "ytp-next"],
                N: {
                    "aria-label": "Show more suggested videos"
                },
                G: [g.F6()]
            });
            g.Q(this, this.W);
            q = q.Y();
            this.j = q.W;
            g.Q(this, this.title);
            this.title.W0(this.element);
            this.suggestions = new g.N({
                D: "div",
                B: "ytp-suggestions"
            });
            g.Q(this, this.suggestions);
            this.suggestions.W0(this.element);
            g.Q(this, this.previous);
            this.previous.W0(this.element);
            this.previous.listen("click", this.O9, this);
            g.Q(this, this.X);
            for (var C = {
                    ZC: 0
                }; C.ZC < 16; C = {
                    ZC: C.ZC
                }, C.ZC++) {
                var c = new g.N({
                    D: "a",
                    B: "ytp-suggestion-link",
                    N: {
                        href: "{{link}}",
                        target: q.Vg,
                        "aria-label": "{{aria_label}}"
                    },
                    G: [{
                        D: "div",
                        B: "ytp-suggestion-image",
                        G: [{
                            D: "div",
                            N: {
                                "data-is-live": "{{is_live}}"
                            },
                            B: "ytp-suggestion-duration",
                            mI: "{{duration}}"
                        }]
                    }, {
                        D: "div",
                        B: "ytp-suggestion-title",
                        N: {
                            title: "{{hover_title}}"
                        },
                        mI: "{{title}}"
                    }, {
                        D: "div",
                        B: "ytp-suggestion-author",
                        mI: "{{views_or_author}}"
                    }]
                });
                g.Q(this, c);
                c.W0(this.suggestions.element);
                var P = c.zH("ytp-suggestion-link");
                g.CU(P, "transitionDelay", C.ZC /
                    20 + "s");
                this.W.Z(P, "click", function(E) {
                    return function(d) {
                        var k = E.ZC,
                            u = J.suggestionData[k],
                            K = u.sessionData;
                        g.D9(J.api.Y()) && J.api.J("web_player_log_click_before_generating_ve_conversion_params") ? (J.api.logClick(J.V[k].element), k = u.j5(), u = {}, g.lA(J.api, u), k = g.GX(k, u), g.Wq(k, J.api, d)) : g.Ka(d, J.api, J.j, K || void 0) && J.api.O8(u.videoId, K, u.playlistId)
                    }
                }(C));
                this.V.push(c)
            }
            g.Q(this, this.next);
            this.next.W0(this.element);
            this.next.listen("click", this.vl, this);
            this.W.Z(this.api, "videodatachange", this.onVideoDataChange);
            this.resize(this.api.MP().getPlayerSize());
            this.onVideoDataChange();
            this.show()
        },
        GWJ = function(q, J) {
            if (q.api.Y().J("web_player_log_click_before_generating_ve_conversion_params"))
                for (var C = Math.floor(-q.scrollPosition / (q.L + q.C)), c = Math.min(C + q.columns, q.suggestionData.length) - 1; C <= c; C++) q.api.logVisibility(q.V[C].element, J)
        },
        mQB = function(q) {
            q.next.element.style.bottom =
                q.K + "px";
            q.previous.element.style.bottom = q.K + "px";
            var J = q.scrollPosition,
                C = q.containerWidth - q.suggestionData.length * (q.L + q.C);
            g.uV(q.element, "ytp-scroll-min", J >= 0);
            g.uV(q.element, "ytp-scroll-max", J <= C)
        },
        UQM = function(q) {
            for (var J = 0; J < q.suggestionData.length; J++) {
                var C = q.suggestionData[J],
                    c = q.V[J],
                    P = C.shortViewCount ? C.shortViewCount : C.author,
                    E = C.j5(),
                    d = q.api.Y();
                if (g.D9(d) && !d.J("web_player_log_click_before_generating_ve_conversion_params")) {
                    var k = {};
                    g.FV(q.api, "addEmbedsConversionTrackingParams", [k]);
                    E = g.GX(E, k)
                }
                c.element.style.display = "";
                k = c.zH("ytp-suggestion-title");
                g.Fe.test(C.title) ? k.dir = "rtl" : g.aqE.test(C.title) && (k.dir = "ltr");
                k = c.zH("ytp-suggestion-author");
                g.Fe.test(P) ? k.dir = "rtl" : g.aqE.test(P) && (k.dir = "ltr");
                c.update({
                    views_or_author: P,
                    duration: C.isLivePlayback ? "Live" : C.lengthSeconds ? g.LJ(C.lengthSeconds) : "",
                    link: E,
                    hover_title: C.title,
                    title: C.title,
                    aria_label: C.ariaLabel || null,
                    is_live: C.isLivePlayback
                });
                P = C.UL();
                c.zH("ytp-suggestion-image").style.backgroundImage = P ? "url(" + P + ")" : "";
                d.J("web_player_log_click_before_generating_ve_conversion_params") && (q.api.createServerVe(c.element, c), (C = (C = C.sessionData) && C.itct) && q.api.setTrackingParams(c.element, C))
            }
            for (; J < q.V.length; J++) q.V[J].element.style.display = "none";
            mQB(q)
        },
        qq = function(q) {
            g.s9.call(this, q);
            var J = this;
            this.V = null;
            var C = q.Y(),
                c = {
                    target: C.Vg
                },
                P = ["ytp-small-redirect"];
            if (C.L) P.push("no-link");
            else {
                var E = g.rt(C);
                c.href = E;
                c["aria-label"] = "Visit YouTube to search for more videos"
            }
            var d = new g.N({
                D: "a",
                O1: P,
                N: c,
                G: [{
                    D: "svg",
                    N: {
                        fill: "#fff",
                        height: "100%",
                        viewBox: "0 0 24 24",
                        width: "100%"
                    },
                    G: [{
                        D: "path",
                        N: {
                            d: "M0 0h24v24H0V0z",
                            fill: "none"
                        }
                    }, {
                        D: "path",
                        N: {
                            d: "M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"
                        }
                    }]
                }]
            });
            d.W0(this.element);
            q.createClientVe(d.element, this, 178053);
            this.Z(d.element, "click", function(k) {
                s_Z(J, k, d.element)
            });
            g.Q(this, d);
            C.L || C.disableOrganicUi || (this.V = new HRY(q), this.V.W0(this.element), g.Q(this, this.V));
            this.Z(q, "videodatachange", function() {
                J.show()
            });
            this.resize(this.api.MP().getPlayerSize())
        },
        s_Z = function(q, J, C) {
            J.preventDefault();
            q.api.logClick(C);
            J = C.getAttribute("href");
            C = {};
            g.FV(q.api, "addEmbedsConversionTrackingParams", [C]);
            J = g.IT(C) ? J : g.GX(J, C);
            g.HB(window, J)
        },
        lwu = function(q, J) {
            q.zH("ytp-error-content").style.paddingTop = "0px";
            var C = q.zH("ytp-error-content"),
                c = C.clientHeight;
            q.V && q.V.resize(J, J.height - c);
            C.style.paddingTop = (J.height - (q.V ? q.V.element.clientHeight : 0)) / 2 - c / 2 + "px"
        },
        ORu = function(q, J) {
            var C = q.api.Y(),
                c;
            J.reason && (DQh(J.reason) ? c = g.W7(J.reason) : c = g.lI(g.K6(J.reason)), q.setContent(c, "content"));
            var P;
            J.subreason && (DQh(J.subreason) ? P = g.W7(J.subreason) : P = g.lI(g.K6(J.subreason)), q.setContent(P, "subreason"));
            if (J.proceedButton && J.proceedButton.buttonRenderer) {
                c = q.zH("ytp-error-content-wrap-subreason");
                J = J.proceedButton.buttonRenderer;
                var E = g.VV("A");
                if (J.text && J.text.simpleText && (P = J.text.simpleText, E.textContent = P, !R$A(c, P) && (!C.L || C.embedsErrorLinks))) {
                    var d;
                    C = (d = g.w(J == null ? void 0 : J.navigationEndpoint,
                        g.sy)) == null ? void 0 : d.url;
                    var k;
                    d = (k = g.w(J == null ? void 0 : J.navigationEndpoint, g.sy)) == null ? void 0 : k.target;
                    C && (E.setAttribute("href", C), q.api.createClientVe(E, q, 178424), q.Z(E, "click", function(u) {
                        s_Z(q, u, E)
                    }));
                    d && E.setAttribute("target", d);
                    k = g.VV("DIV");
                    k.appendChild(E);
                    c.appendChild(k)
                }
            }
        },
        DQh = function(q) {
            if (q.runs)
                for (var J = 0; J < q.runs.length; J++)
                    if (q.runs[J].navigationEndpoint) return !0;
            return !1
        },
        R$A = function(q, J) {
            q = g.tG("A", q);
            for (var C = 0; C < q.length; C++)
                if (q[C].textContent === J) return !0;
            return !1
        },
        MQU = function(q, J) {
            g.N.call(this, {
                D: "a",
                O1: ["ytp-impression-link"],
                N: {
                    target: "{{target}}",
                    href: "{{url}}",
                    "aria-label": "Watch on YouTube"
                },
                G: [{
                    D: "div",
                    B: "ytp-impression-link-content",
                    N: {
                        "aria-hidden": "true"
                    },
                    G: [{
                        D: "div",
                        B: "ytp-impression-link-text",
                        mI: "Watch on"
                    }, {
                        D: "div",
                        B: "ytp-impression-link-logo",
                        mI: "{{logoSvg}}"
                    }]
                }]
            });
            this.api = q;
            this.V = J;
            this.updateValue("target", q.Y().Vg);
            this.Z(q, "videodatachange", this.onVideoDataChange);
            this.Z(this.api, "presentingplayerstatechange", this.dS);
            this.Z(this.api, "videoplayerreset", this.Ky);
            this.Z(this.element,
                "click", this.onClick);
            this.onVideoDataChange();
            this.Ky()
        },
        BCh = function(q) {
            var J = {};
            g.FV(q.api, "addEmbedsConversionTrackingParams", [J]);
            q = q.api.getVideoUrl();
            return q = g.GX(q, J)
        },
        JJ = function(q) {
            g.N.call(this, {
                D: "div",
                O1: ["ytp-mobile-a11y-hidden-seek-button"],
                G: [{
                    D: "button",
                    O1: ["ytp-mobile-a11y-hidden-seek-button-rewind", "ytp-button"],
                    N: {
                        "aria-label": "Rewind 10 seconds",
                        "aria-hidden": "false"
                    }
                }, {
                    D: "button",
                    O1: ["ytp-mobile-a11y-hidden-seek-button-forward", "ytp-button"],
                    N: {
                        "aria-label": "Fast forward 10 seconds",
                        "aria-hidden": "false"
                    }
                }]
            });
            this.api = q;
            this.V = this.zH("ytp-mobile-a11y-hidden-seek-button-rewind");
            this.forwardButton = this.zH("ytp-mobile-a11y-hidden-seek-button-forward");
            this.api.createClientVe(this.V, this,
                141902);
            this.api.createClientVe(this.forwardButton, this, 141903);
            this.Z(this.api, "presentingplayerstatechange", this.dS);
            this.Z(this.V, "click", this.C);
            this.Z(this.forwardButton, "click", this.L);
            this.dS()
        },
        C8 = function(q) {
            g.N.call(this, {
                D: "div",
                B: "ytp-muted-autoplay-endscreen-overlay",
                G: [{
                    D: "div",
                    B: "ytp-muted-autoplay-end-panel",
                    G: [{
                        D: "button",
                        O1: ["ytp-muted-autoplay-end-text", "ytp-button"],
                        mI: "{{text}}"
                    }]
                }]
            });
            this.api = q;
            this.W = this.zH("ytp-muted-autoplay-end-panel");
            this.C = !1;
            this.api.createClientVe(this.element, this, 52428);
            this.Z(this.api, "presentingplayerstatechange", this.L);
            this.Z(q, "onMutedAutoplayStarts", this.onMutedAutoplayStarts);
            this.listen("click", this.onClick);
            this.hide()
        },
        c3 = function(q) {
            var J = q.Y();
            g.N.call(this, {
                D: "a",
                O1: ["ytp-watermark", "yt-uix-sessionlink"],
                N: {
                    target: J.Vg,
                    href: "{{url}}",
                    "aria-label": g.zn("Watch on $WEBSITE", {
                        WEBSITE: g.j7(J)
                    }),
                    "data-sessionlink": "feature=player-watermark"
                },
                mI: "{{logoSvg}}"
            });
            this.api = q;
            this.V = null;
            this.C = !1;
            this.state = q.getPlayerStateObject();
            this.Z(q, "videodatachange", this.onVideoDataChange);
            this.Z(q, "presentingplayerstatechange", this.onStateChange);
            this.Z(q, "appresize", this.lE);
            this.onVideoDataChange();
            this.Be(this.state);
            this.lE(q.MP().getPlayerSize())
        },
        xQU = function(q) {
            var J = q.api.getVideoData(),
                C = q.api.Y().Ks && !g.b(q.state, 2) && !q.api.getVideoData(1).G8;
            J.mutedAutoplay || q.NQ(C);
            q.api.logVisibility(q.element, C)
        },
        e$N = function(q) {
            g.N.call(this, {
                D: "div",
                B: "ytp-muted-autoplay-overlay",
                G: [{
                    D: "div",
                    B: "ytp-muted-autoplay-bottom-buttons",
                    G: [{
                        D: "button",
                        O1: ["ytp-muted-autoplay-equalizer", "ytp-button"],
                        N: {
                            "aria-label": "Muted Playback Indicator"
                        },
                        G: [{
                            D: "div",
                            O1: ["ytp-muted-autoplay-equalizer-icon"],
                            G: [{
                                D: "svg",
                                N: {
                                    height: "100%",
                                    version: "1.1",
                                    viewBox: "-4 -4 24 24",
                                    width: "100%"
                                },
                                G: [{
                                    D: "g",
                                    N: {
                                        fill: "#fff"
                                    },
                                    G: [{
                                            D: "rect",
                                            B: "ytp-equalizer-bar-left",
                                            N: {
                                                height: "9",
                                                width: "4",
                                                x: "1",
                                                y: "7"
                                            }
                                        }, {
                                            D: "rect",
                                            B: "ytp-equalizer-bar-middle",
                                            N: {
                                                height: "14",
                                                width: "4",
                                                x: "6",
                                                y: "2"
                                            }
                                        },
                                        {
                                            D: "rect",
                                            B: "ytp-equalizer-bar-right",
                                            N: {
                                                height: "12",
                                                width: "4",
                                                x: "11",
                                                y: "4"
                                            }
                                        }
                                    ]
                                }]
                            }]
                        }]
                    }]
                }]
            });
            var J = this;
            this.api = q;
            this.bottomButtons = this.zH("ytp-muted-autoplay-bottom-buttons");
            this.L = new g.bu(this.WIv, 4E3, this);
            this.C = !1;
            q.createClientVe(this.element, this, 39306);
            this.Z(q, "presentingplayerstatechange", this.kA);
            this.Z(q, "onMutedAutoplayStarts", function() {
                Q_h(J);
                J.kA();
                awB(J);
                J.C = !1
            });
            this.Z(q, "onAutoplayBlocked", this.onAutoplayBlocked);
            this.listen("click", this.onClick);
            this.Z(q, "onMutedAutoplayEnds", this.onMutedAutoplayEnds);
            this.hide();
            q.isMutedByEmbedsMutedAutoplay() && (Q_h(this), this.kA(), awB(this));
            g.Q(this, this.L)
        },
        awB = function(q) {
            q.s3 && q.V && (q.V.show(), q.L.start())
        },
        Q_h = function(q) {
            q.watermark || (q.watermark = new c3(q.api), g.Q(q, q.watermark), q.watermark.W0(q.bottomButtons, 0), g.uV(q.watermark.element, "ytp-muted-autoplay-watermark", !0), q.V = new g.jY(q.watermark, 0, !0, 100), g.Q(q,
                q.V))
        },
        P3 = function(q) {
            g.N.call(this, {
                D: "div",
                B: "ytp-pause-overlay",
                N: {
                    tabIndex: "-1"
                }
            });
            var J = this;
            this.api = q;
            this.L = new g.uy(this);
            this.fade = new g.jY(this, 1E3, !1, 100, function() {
                J.V.C = !1
            }, function() {
                J.V.C = !0
            });
            this.C = !1;
            this.expandButton = new g.N({
                D: "button",
                O1: ["ytp-button", "ytp-expand"],
                mI: this.api.isEmbedsShortsMode() ? "More shorts" : "More videos"
            });
            q.Y().controlsType === "0" && g.E8(q.getRootNode(), "ytp-pause-overlay-controls-hidden");
            g.Q(this, this.L);
            g.Q(this, this.fade);
            var C = new g.N({
                D: "button",
                O1: ["ytp-button", "ytp-collapse"],
                N: {
                    "aria-label": this.api.isEmbedsShortsMode() ? "Hide more shorts" : "Hide more videos"
                },
                G: [{
                    D: "div",
                    B: "ytp-collapse-icon",
                    G: [g.Y0()]
                }]
            });
            g.Q(this, C);
            C.W0(this.element);
            C.listen("click",
                this.W, this);
            g.Q(this, this.expandButton);
            this.expandButton.W0(this.element);
            this.expandButton.listen("click", this.K, this);
            this.V = new g.fn(q);
            g.Q(this, this.V);
            this.V.C = !1;
            this.V.W0(this.element);
            this.api.isEmbedsShortsMode() ? this.api.createClientVe(this.element, this, 157212) : this.api.createClientVe(this.element, this, 172777);
            this.L.Z(this.api, "presentingplayerstatechange", this.jg);
            this.L.Z(this.api, "videodatachange", this.jg);
            this.hide()
        },
        EX = function(q) {
            g.N.call(this, {
                D: "div",
                O1: ["ytp-player-content", "ytp-iv-player-content"],
                G: [{
                    D: "div",
                    B: "ytp-countdown-timer",
                    G: [{
                        D: "svg",
                        N: {
                            height: "100%",
                            version: "1.1",
                            viewBox: "0 0 72 72",
                            width: "100%"
                        },
                        G: [{
                            D: "circle",
                            B: "ytp-svg-countdown-timer-ring",
                            N: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-dasharray": "211",
                                "stroke-dashoffset": "-211",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }, {
                            D: "circle",
                            B: "ytp-svg-countdown-timer-background",
                            N: {
                                cx: "-36",
                                cy: "36",
                                "fill-opacity": "0",
                                r: "33.5",
                                stroke: "#FFFFFF",
                                "stroke-opacity": "0.3",
                                "stroke-width": "4",
                                transform: "rotate(-90)"
                            }
                        }]
                    }, {
                        D: "span",
                        B: "ytp-countdown-timer-time",
                        mI: "{{duration}}"
                    }]
                }]
            });
            this.api = q;
            this.S = this.zH("ytp-svg-countdown-timer-ring");
            this.V = null;
            this.W = this.L = 0;
            this.C = !1;
            this.K = 0;
            this.api.createClientVe(this.element, this, 159628)
        },
        vwh = function(q) {
            q.V || (q.L = 5E3, q.W = (0, g.XD)(), q.V = new g.iu(function() {
                NCY(q)
            }, null), NCY(q))
        },
        NCY = function(q) {
            if (!q.C) {
                var J = Math.min((0, g.XD)() - q.W, q.L);
                var C = q.L - J;
                J = q.L === 0 ? 0 : Math.max(C / q.L, 0);
                C = Math.round(C / 1E3);
                q.S.setAttribute("stroke-dashoffset", "" + -211 * (J + 1));
                q.updateValue("duration", C);
                J <= 0 && q.V ? q.stopTimer() : q.V && q.V.start()
            }
        },
        bRU = function(q) {
            g.ZS.call(this, q);
            this.U = q;
            this.V = new g.uy(this);
            this.C = null;
            this.j = !1;
            this.countdownTimer = null;
            this.Vg = !1;
            iRu(this);
            g.Q(this, this.V);
            this.load()
        },
        h$B = function(q) {
            var J = g.ByR(q.U);
            J !== q.Vg && (q.Vg = J, q.K && (q.K.dispose(), q.K = null), q.L && (q.L.dispose(), q.L = null), q.W && (q.W.dispose(), q.W = null), q.C && (q.C.stop(), q.C.dispose(), q.C = null), J && (J = g.LW(q.U), q.U.isEmbedsShortsMode() && (q.W = new g.N({
                D: "div",
                B: "ytp-pause-overlay-backdrop",
                N: {
                    tabIndex: "-1"
                }
            }), g.Q(q, q.W), g.OL(q.U, q.W.element, 4), q.C = new g.jY(q.W, 1E3, !1, 100), g.Q(q, q.C), q.W.hide()), q.K = new g.N({
                D: "div",
                B: "ytp-pause-overlay-container",
                N: {
                    tabIndex: "-1"
                }
            }), g.Q(q, q.K), q.L = new P3(q.U, J), g.Q(q, q.L), q.L.W0(q.K.element), g.OL(q.U, q.K.element,
                4), fw1(q, q.U.getPlayerStateObject())))
        },
        fw1 = function(q, J) {
            q.C && (!g.b(J, 4) && !g.b(J, 2) || g.b(J, 1024) ? q.C.hide() : q.C.show())
        },
        iRu = function(q) {
            var J = q.U;
            q = !!J.isEmbedsShortsMode();
            g.uV(J.getRootNode(), "ytp-shorts-mode", q);
            if (J = J.getVideoData()) J.dD = q
        },
        dl = function(q, J) {
            var C = q.U.Y();
            q = {
                adSource: "EMBEDS_AD_SOURCE_YOUTUBE",
                breakType: q.U.getCurrentTime() === 0 ? "EMBEDS_AD_BREAK_TYPE_PRE_ROLL" : q.U.getPlayerState() === 0 ? "EMBEDS_AD_BREAK_TYPE_POST_ROLL" : "EMBEDS_AD_BREAK_TYPE_MID_ROLL",
                embedUrl: g.EXj(q.U.Y().loaderUrl),
                eventType: J,
                youtubeHost: g.XU(q.U.Y().QF) || ""
            };
            q.embeddedPlayerMode = C.LV;
            g.rr("embedsAdEvent", q)
        };
    g.y(HRY, g.N);
    g.t = HRY.prototype;
    g.t.hide = function() {
        this.S = !0;
        g.N.prototype.hide.call(this);
        GWJ(this, !1)
    };
    g.t.show = function() {
        this.S = !1;
        g.N.prototype.show.call(this);
        GWJ(this, !0)
    };
    g.t.isHidden = function() {
        return this.S
    };
    g.t.vl = function() {
        this.scrollTo(this.scrollPosition - this.containerWidth)
    };
    g.t.O9 = function() {
        this.scrollTo(this.scrollPosition + this.containerWidth)
    };
    g.t.resize = function(q, J) {
        var C = this.api.Y(),
            c = 16 / 9,
            P = q.width >= 650,
            E = q.width < 480 || q.height < 290,
            d = Math.min(this.suggestionData.length, this.V.length);
        if (Math.min(q.width, q.height) <= 150 || d === 0 || !C.Cs) this.hide();
        else {
            var k;
            if (P) {
                var u = k = 28;
                this.C = 16
            } else this.C = u = k = 8;
            if (E) {
                var K = 6;
                P = 14;
                var W = 12;
                E = 24;
                C = 12
            } else K = 8, P = 18, W = 16, E = 36, C = 16;
            q = q.width - (48 + k + u);
            k = Math.ceil(q / 150);
            k = Math.min(3, k);
            u = q / k - this.C;
            var r = Math.floor(u / c);
            J && r + 100 > J && u > 50 && (r = Math.max(J, 50 / c), k = Math.ceil(q / (c * (r - 100) + this.C)), u = q / k - this.C,
                r = Math.floor(u / c));
            u < 50 || g.sL(this.api) ? this.hide() : this.show();
            for (J = 0; J < d; J++) {
                c = this.V[J];
                var Z = c.zH("ytp-suggestion-image");
                Z.style.width = u + "px";
                Z.style.height = r + "px";
                c.zH("ytp-suggestion-title").style.width = u + "px";
                c.zH("ytp-suggestion-author").style.width = u + "px";
                c = c.zH("ytp-suggestion-duration");
                c.style.display = c && u < 100 ? "none" : ""
            }
            d = P + K + W + 4;
            this.K = d + C + (r - E) / 2;
            this.suggestions.element.style.height = r + d + "px";
            this.L = u;
            this.containerWidth = q;
            this.columns = k;
            this.scrollPosition = 0;
            this.suggestions.element.scrollLeft = -0;
            mQB(this)
        }
    };
    g.t.onVideoDataChange = function() {
        var q = this.api.getVideoData(),
            J = this.api.Y();
        this.j = q.G8 ? !1 : J.W;
        q.suggestions ? this.suggestionData = g.Rf(q.suggestions, function(C) {
            return C && !C.playlistId
        }) : this.suggestionData.length = 0;
        UQM(this);
        q.G8 ? this.title.update({
            title: g.zn("More videos from $DNI_RELATED_CHANNEL", {
                DNI_RELATED_CHANNEL: q.author
            })
        }) : this.title.update({
            title: "More videos on YouTube"
        })
    };
    g.t.scrollTo = function(q) {
        q = g.q3(q, this.containerWidth - this.suggestionData.length * (this.L + this.C), 0);
        this.X.start(this.scrollPosition, q, 1E3);
        this.scrollPosition = q;
        mQB(this);
        GWJ(this, !0)
    };
    g.y(qq, g.s9);
    qq.prototype.show = function() {
        g.s9.prototype.show.call(this);
        lwu(this, this.api.MP().getPlayerSize())
    };
    qq.prototype.resize = function(q) {
        g.s9.prototype.resize.call(this, q);
        this.V && (lwu(this, q), g.uV(this.element, "related-on-error-overlay-visible", !this.V.isHidden()))
    };
    qq.prototype.C = function(q) {
        g.s9.prototype.C.call(this, q);
        var J = this.api.getVideoData();
        if (J.Yq || J.playerErrorMessageRenderer)(q = J.Yq) ? ORu(this, q) : J.playerErrorMessageRenderer && ORu(this, J.playerErrorMessageRenderer);
        else {
            var C;
            q.Xw && (J.pP ? DQh(J.pP) ? C = g.W7(J.pP) : C = g.lI(g.K6(J.pP)) : C = g.lI(q.Xw), this.setContent(C, "subreason"))
        }
    };
    g.y(MQU, g.N);
    g.t = MQU.prototype;
    g.t.onVideoDataChange = function() {
        var q = this.api.getVideoData(),
            J = ow1(),
            C = 96714;
        g.d1(q) ? (J = IwN(), C = 216165, g.E8(this.element, "ytp-music-impression-link")) : g.Tf(this.element, "ytp-music-impression-link");
        this.updateValue("logoSvg", J);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this, C)
    };
    g.t.dS = function() {
        this.api.getPlayerStateObject().isCued() || (this.hide(), this.api.logVisibility(this.element, !1))
    };
    g.t.Ky = function() {
        var q = this.api.getVideoData(),
            J = this.api.Y(),
            C = this.api.getVideoData().G8,
            c = !J.Cs,
            P = this.V.YB(),
            E = J.L;
        J.Ks || P || C || c || E || this.api.isEmbedsShortsMode() || !q.videoId ? (this.hide(), this.api.logVisibility(this.element, !1)) : (q = BCh(this), this.updateValue("url", q), this.show())
    };
    g.t.onClick = function(q) {
        this.api.J("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var J = BCh(this);
        g.Wq(J, this.api, q);
        this.api.J("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.t.show = function() {
        this.api.getPlayerStateObject().isCued() && (g.N.prototype.show.call(this), this.api.hasVe(this.element) && this.api.logVisibility(this.element, !0))
    };
    g.y(JJ, g.N);
    JJ.prototype.dS = function() {
        var q = this.api.getPlayerStateObject();
        !this.api.AN() || g.b(q, 2) && g.Hc(this.api) || g.b(q, 64) ? (this.api.logVisibility(this.V, !1), this.api.logVisibility(this.forwardButton, !1), this.hide()) : (this.show(), this.api.logVisibility(this.V, !0), this.api.logVisibility(this.forwardButton, !0))
    };
    JJ.prototype.C = function() {
        this.api.seekBy(-10 * this.api.getPlaybackRate(), void 0, void 0, 83);
        this.api.logClick(this.V)
    };
    JJ.prototype.L = function() {
        this.api.seekBy(10 * this.api.getPlaybackRate(), void 0, void 0, 82);
        this.api.logClick(this.forwardButton)
    };
    g.y(C8, g.N);
    C8.prototype.L = function() {
        var q = this.api.getPlayerStateObject(),
            J = this.api.getVideoData();
        g.uV(this.element, "ytp-shorts-mode", this.api.isEmbedsShortsMode());
        !J.mutedAutoplay || J.limitedPlaybackDurationInSeconds === 0 && J.endSeconds === 0 && J.mutedAutoplayDurationMode === 2 || (g.b(q, 2) && !this.s3 ? (this.show(), this.V || (this.V = new g.ma(this.api), g.Q(this, this.V), this.V.W0(this.W, 0), this.V.show()), q = this.api.getVideoData(), this.updateValue("text", q.cP), g.uV(this.element, "ytp-muted-autoplay-show-end-panel", !0), this.api.logVisibility(this.element,
            this.s3), this.api.mz("onMutedAutoplayEnds")) : this.hide())
    };
    C8.prototype.onClick = function() {
        if (!this.C) {
            this.V && (this.V.s1(), this.V = null);
            g.uV(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var q = this.api.getVideoData(),
                J = this.api.getCurrentTime();
            YtY(q);
            this.api.loadVideoById(q.videoId, J);
            this.api.CM();
            this.api.logClick(this.element);
            this.hide();
            this.C = !0
        }
    };
    C8.prototype.onMutedAutoplayStarts = function() {
        this.C = !1;
        this.V && (this.V.s1(), this.V = null)
    };
    g.y(c3, g.N);
    g.t = c3.prototype;
    g.t.onStateChange = function(q) {
        this.Be(q.state)
    };
    g.t.Be = function(q) {
        this.state !== q && (this.state = q);
        xQU(this)
    };
    g.t.onVideoDataChange = function() {
        var q = this.api.Y();
        q.L && g.E8(this.element, "ytp-no-hover");
        var J = this.api.getVideoData();
        J.videoId && !q.L ? (q = this.api.getVideoUrl(!0, !1, !1, !0), this.updateValue("url", q), this.V || (this.V = this.listen("click", this.onClick))) : this.V && (this.updateValue("url", null), this.DM(this.V), this.V = null);
        q = ow1();
        var C = 76758;
        g.d1(J) && (q = IwN(), C = 216164);
        this.updateValue("logoSvg", q);
        this.api.hasVe(this.element) && this.api.destroyVe(this.element);
        this.api.createClientVe(this.element, this,
            C);
        xQU(this)
    };
    g.t.onClick = function(q) {
        this.api.J("web_player_log_click_before_generating_ve_conversion_params") && this.api.logClick(this.element);
        var J = this.api.getVideoUrl(!g.A1(q), !1, !0, !0);
        if (this.api.J("web_player_log_click_before_generating_ve_conversion_params")) {
            var C = {};
            g.FV(this.api, "addEmbedsConversionTrackingParams", [C]);
            J = g.GX(J, C)
        }
        g.Wq(J, this.api, q);
        this.api.J("web_player_log_click_before_generating_ve_conversion_params") || this.api.logClick(this.element)
    };
    g.t.lE = function(q) {
        if ((q = q.width < 480) && !this.C || !q && this.C) {
            var J = new g.N(ow1()),
                C = this.zH("ytp-watermark");
            g.uV(C, "ytp-watermark-small", q);
            g.IQ(C);
            J.W0(C);
            this.C = q
        }
    };
    g.y(e$N, g.N);
    g.t = e$N.prototype;
    g.t.kA = function() {
        var q = this.api.getPlayerStateObject();
        !this.api.getVideoData().mutedAutoplay || g.b(q, 2) ? this.hide() : this.s3 || (g.N.prototype.show.call(this), this.api.logVisibility(this.element, this.s3))
    };
    g.t.WIv = function() {
        this.V && this.V.hide()
    };
    g.t.onAutoplayBlocked = function() {
        this.hide();
        YtY(this.api.getVideoData())
    };
    g.t.onClick = function() {
        if (!this.C) {
            g.uV(this.api.getRootNode(), "ytp-muted-autoplay", !1);
            var q = this.api.getVideoData(),
                J = this.api.getCurrentTime();
            YtY(q);
            this.api.loadVideoById(q.videoId, J);
            this.api.CM();
            this.api.logClick(this.element);
            this.api.mz("onMutedAutoplayEnds");
            this.C = !0
        }
    };
    g.t.onMutedAutoplayEnds = function() {
        this.watermark && (this.watermark.s1(), this.watermark = null)
    };
    g.y(P3, g.N);
    P3.prototype.hide = function() {
        g.Tf(this.api.getRootNode(), "ytp-expand-pause-overlay");
        g.N.prototype.hide.call(this)
    };
    P3.prototype.W = function() {
        this.C = !0;
        g.Tf(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !1);
        this.expandButton.focus()
    };
    P3.prototype.K = function() {
        this.C = !1;
        g.E8(this.api.getRootNode(), "ytp-expand-pause-overlay");
        this.api.isEmbedsShortsMode() && this.api.logVisibility(this.element, !0);
        this.focus()
    };
    P3.prototype.jg = function() {
        var q = this.api.getPlayerStateObject();
        g.b(q, 1) || g.b(q, 16) || g.b(q, 32) || (!g.b(q, 4) || g.b(q, 2) || g.b(q, 1024) ? (this.C || this.api.logVisibility(this.element, !1), this.fade.hide()) : this.V.hasSuggestions() && (this.C || (g.E8(this.api.getRootNode(), "ytp-expand-pause-overlay"), g.hv(this.V), this.V.show(), this.api.logVisibility(this.element, !0)), this.fade.show()))
    };
    g.y(EX, g.N);
    EX.prototype.show = function() {
        g.N.prototype.show.call(this);
        this.api.logVisibility(this.element, !0)
    };
    EX.prototype.stopTimer = function() {
        this.V && (this.V.dispose(), this.V = null, this.C = !1)
    };
    EX.prototype.s1 = function() {
        this.stopTimer();
        g.N.prototype.s1.call(this)
    };
    g.y(bRU, g.ZS);
    g.t = bRU.prototype;
    g.t.Ey = function() {
        return !1
    };
    g.t.create = function() {
        var q = this.U.Y(),
            J = g.LW(this.U),
            C, c = (C = this.U.getVideoData()) == null ? void 0 : C.clientPlaybackNonce;
        c && g.Y6({
            clientPlaybackNonce: c
        });
        q.o2 && !q.disableOrganicUi && h$B(this);
        var P;
        (P = q.getWebPlayerContextConfig()) != null && P.embedsEnableEmc3ds || (this.X = new e$N(this.U), g.Q(this, this.X), g.OL(this.U, this.X.element, 4), this.CV = new C8(this.U), g.Q(this, this.CV), g.OL(this.U, this.CV.element, 4));
        q.Ks && (this.watermark = new c3(this.U), g.Q(this, this.watermark), g.OL(this.U, this.watermark.element, 8));
        J && !q.disableOrganicUi && (this.S = new MQU(this.U, J), g.Q(this, this.S), g.OL(this.U, this.S.element, 8), this.U.isMutedByEmbedsMutedAutoplay() && (this.onMutedAutoplayStarts(), this.S.hide()));
        q.C && !q.disableOrganicUi && (this.d5 = new JJ(this.U), g.Q(this, this.d5), g.OL(this.U, this.d5.element, 4));
        this.V.Z(this.U, "appresize", this.lE);
        this.V.Z(this.U, "presentingplayerstatechange", this.dS);
        this.V.Z(this.U, "videodatachange", this.onVideoDataChange);
        this.V.Z(this.U, "videoplayerreset", this.onReset);
        this.V.Z(this.U, "onMutedAutoplayStarts",
            this.onMutedAutoplayStarts);
        this.V.Z(this.U, "onAdStart", this.onAdStart);
        this.V.Z(this.U, "onAdComplete", this.onAdComplete);
        this.V.Z(this.U, "onAdSkip", this.onAdSkip);
        this.V.Z(this.U, "onAdStateChange", this.onAdStateChange);
        if (this.j = g.FX(g.Ne(q))) this.countdownTimer = new EX(this.U), g.Q(this, this.countdownTimer), g.OL(this.U, this.countdownTimer.element, 4), this.countdownTimer.hide(), this.V.Z(this.U, g.ML("embeds"), this.onCueRangeEnter), this.V.Z(this.U, g.BM("embeds"), this.onCueRangeExit);
        this.Vr(this.U.getPlayerStateObject());
        var E, d;
        ((E = this.U.Y().getWebPlayerContextConfig()) == null ? 0 : (d = E.embedsHostFlags) == null ? 0 : d.allowOverridingVisitorDataPlayerVars) && (q = g.z1("IDENTITY_MEMENTO")) && this.U.D5("onMementoChange", q)
    };
    g.t.onCueRangeEnter = function(q) {
        q.getId() === "countdown timer" && this.countdownTimer && (this.countdownTimer.show(), vwh(this.countdownTimer))
    };
    g.t.onCueRangeExit = function(q) {
        q.getId() === "countdown timer" && this.countdownTimer && (this.countdownTimer.stopTimer(), this.countdownTimer.hide())
    };
    g.t.lE = function() {
        var q = this.U.MP().getPlayerSize();
        this.Kb && this.Kb.resize(q)
    };
    g.t.onReset = function() {
        iRu(this)
    };
    g.t.dS = function(q) {
        this.Vr(q.state)
    };
    g.t.Vr = function(q) {
        g.b(q, 128) ? (this.Kb || (this.Kb = new qq(this.U), g.Q(this, this.Kb), g.OL(this.U, this.Kb.element, 4)), this.Kb.C(q.F$), this.Kb.show(), g.E8(this.U.getRootNode(), "ytp-embed-error")) : this.Kb && (this.Kb.dispose(), this.Kb = null, g.Tf(this.U.getRootNode(), "ytp-embed-error"));
        if (this.countdownTimer && this.countdownTimer.V)
            if (g.b(q, 64)) this.countdownTimer.hide(), this.countdownTimer.stopTimer();
            else if (q.isPaused()) {
            var J = this.countdownTimer;
            J.C || (J.C = !0, J.K = (0, g.XD)())
        } else q.isPlaying() && this.countdownTimer.C &&
            (J = this.countdownTimer, J.C && (J.W += (0, g.XD)() - J.K, J.C = !1, NCY(J)));
        fw1(this, q)
    };
    g.t.onMutedAutoplayStarts = function() {
        this.U.getVideoData().mutedAutoplay && this.X && g.uV(this.U.getRootNode(), "ytp-muted-autoplay", !0)
    };
    g.t.onVideoDataChange = function(q, J) {
        var C = this.HK !== J.videoId;
        q = !C && q === "dataloaded";
        var c = {
            isShortsModeEnabled: !!this.U.isEmbedsShortsMode()
        };
        g.rr("embedsVideoDataDidChange", {
            clientPlaybackNonce: J.clientPlaybackNonce,
            isReload: q,
            runtimeEnabledFeatures: c
        });
        C && (this.HK = J.videoId, this.countdownTimer && (this.countdownTimer.show(), this.countdownTimer.hide()), this.j && (this.U.DN("embeds"), J.isAd() || J.limitedPlaybackDurationInSeconds < 5 || g.sL(this.U) || (J = Math.max((J.startSeconds + J.limitedPlaybackDurationInSeconds -
            5) * 1E3, 0), J = new g.Ro(J, J + 5E3, {
            id: "countdown timer",
            namespace: "embeds"
        }), this.U.XI([J]))), this.U.Y().o2 && !this.U.Y().disableOrganicUi && (iRu(this), h$B(this)));
        this.U.Y().L && this.L && this.L.detach()
    };
    g.t.onAdStart = function() {
        dl(this, "EMBEDS_AD_EVENT_TYPE_AD_STARTED")
    };
    g.t.onAdComplete = function() {
        dl(this, "EMBEDS_AD_EVENT_TYPE_AD_COMPLETED")
    };
    g.t.onAdSkip = function() {
        dl(this, "EMBEDS_AD_EVENT_TYPE_AD_SKIPPED")
    };
    g.t.onAdStateChange = function(q) {
        q === 2 && dl(this, "EMBEDS_AD_EVENT_TYPE_AD_PAUSED")
    };
    g.rg("embed", bRU);
})(_yt_player);